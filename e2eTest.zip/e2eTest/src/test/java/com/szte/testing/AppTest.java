package test.java.com.szte.testing;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.util.List;
import java.util.Properties;
import java.util.function.Consumer;

public class AppTest {
    private WebDriver browser;

    @Before
    public void Before() {
        String drivePath = FileSystems.getDefault().getPath("src/test/resources/chromedriver.exe").toString();
        System.setProperty("webdriver.chrome.driver", driverPath);

        ChromeOptions options = new ChromeOptions();
        browser = new ChromeDriver(options);
    }

    @Test
    public void E2ETest(){
        browser.get("http://automationpractice.com/");

        WebElement signInButton = browser.findElement(By.cssSelector("a.login"));
        signInButton.click();

        WebElement submitLoginButton = browser.findElement(By.id("SubmitLogin"));
        (new WebDriverWait(browser, 10)).until(ExpectedConditions.elementToBeClickable(submitLoginButton));

        WebElement email = browser.findElement(By.id("email"));
        WebElement passwd = browser.findElement(By.id("passwd"));

        email.sendKeys("gyoszabi97@gmail.com");
        passwd.sendKeys("Teszt123");
        submitLoginButton.click();

        WebElement myAccountButton = browser.findElement(By.cssSelector("a.account"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(myAccountButton));

        assertEquals("The account logged in is not the expected one!", "szte test", myAccountButton.getText());

        WebElement dressesButton = browser.findElement(By.title("Dresses"));
        dressesButton.click();
        (new WebDriverWait(browser,10)).until(ExpectedConditions.elementToBeClickable(dressesButton));

        WebElement printedDressButton = browser.findElement(By.href("http://automationpractice.com/index.php?id_product=4&controller=product"));
        printedDressButton.click();
        (new WebDriverWait(browser, 10)).until(ExceptedConditions.elementToBeClickable(printedDressButton));

        WebElement addToCartButton = browser.findElement(By.name("submit"));
        addToCartButton.click();
        (new DriverWait(browser, 10)).until(ExpectedConditions.elementToBeClickable(addToCartButton));

        assertEquals("The dress is in the cart!", "szte test", addToCartButton.getText());

        webElement proceedToCheckoutButton = browser.findElement(By.cssSelector("a.btn btn-default button button-medium"));
        proceedToCheckoutButton.click();
        (new WebDriverWait(browser, 10)).until(ExpectedConditions.elementToBeClickable(proceedToCheckoutButton));

        webElement plusButton = browser.findElement(By.cssSelector("i.icon-plus"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(plusButton));

        webElement proceedToCheckoutButton2 = browser.findElement(By.cssSelector("a.button btn btn-default standard-checkout button-medium"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(proceedToCheckoutButton2));

        webElement deliveryAsBillingButton = browser.findElement(By.name("same"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(deliveryAsBillingButton));

        webElement differentAddressButton = browser.findElement(By.name("id_address_invoice"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(differentAddressButton));

        assertEquals("The two address is not the same.", "szte test", differentAddressButton.getText());

        webElement proceedToCheckoutButton3 = browser.findElement(By.cssSelector("button.button btn btn-default button-medium"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(proceedToCheckoutButton3));

        webElement termsOfServiceButton = browser.findElement(By.name("cgv"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(termsOfServiceButton));

        webElement proceedToCheckoutButton4 = browser.findElement(By.cssSelector("button.button btn btn-default standard-checkout button-medium"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(proceedToCheckoutButton4));

        webElement totalPrice = browser.findElement(By.id("total_price"));
        assertEquals("The total price is right", "$108.14", totalPrice);

        webElement payBuyCheckButton = browser.findElement(By.cssSelector("a.cheque"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(payBuyCheckButton));

        webElement confirmOrderButton = browser.findElement(By.cssSelector("button.button btn btn-default button-medium"));
        (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(confirmOrderButton));

        webElement successfulOrder = browser.findElement(By.cssSelector("p.alert alert-success"));


    }
    @After
    public void After() {
        browser.quit();
    }

}

