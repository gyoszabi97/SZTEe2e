package com.szte.testing.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AppPage(){
    private final WebDriver browser;

        By emailLocator = By.id("email");
        By passwordLocator = By.id("passwd");
        By submitLoginButtonLocator = By.id("SubmitLogin");
        By myAccountButton = By.cssSelector("a.account");
        By dressesButton = By.title("Dresses");
        By printedDressButton = By.href("http://automationpractice.com/index.php?id_product=4&controller=product");
        By addToCartButton = By.name("submit");
        By proceedToCheckout = By.cssSelector("a.btn btn-default button button-medium");
        By plusButton = By.cssSelector("i.icon-plus");
        By proceedToCheckout2 = By.cssSelector("a.button btn btn-default standard-checkout button-medium");
        By deliveryAsBillingButton = By.name("same");
        By differentAddressButton = By.name("id_address_invoice");
        By proceedToCheckoutButton3 = By.cssSelector("button.button btn btn-default button-medium");
        By termsOfServiceButton = By.name("cgv");
        By proceedToCheckoutButton4 = By.cssSelector("button.button btn btn-default standard-checkout button-medium");
        By totalPrice = By.id("total_price");
        By payBuyCheckButton = By.cssSelector("a.cheque");
        By confirmOrderButton = By.cssSelector("button.button btn btn-default button-medium");
        By succesfullOrder = By.cssSelector("p.alert alert-success");

        public LoginPage(WebDriver browser) {
                this.browser = browser;

                // wait until the page is interactable
                WebElement submitLoginButton = browser.findElement(submitLoginButtonLocator);
                (new WebDriverWait(browser, 5)).until(ExpectedConditions.elementToBeClickable(submitLoginButton));
                }

        public LoginPage typeEmail(String email) {
                browser.findElement(emailLocator).sendKeys(email);
                return this;
                }

        public LoginPage typePassword(String password) {
                browser.findElement(passwordLocator).sendKeys(password);
                return this;
                }


        }